import sys
import mysql.connector

# Connect to MySQL
db_connection = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="tiger",
    database="student"
)

# Create a cursor
cursor = db_connection.cursor()

# Add Records
def Add():
    var = True
    while var:
        rno = input("Enter RollNo number: ")
        name = input("Enter a Name: ")
        phone = input("Enter your Phone Number: ")
        city = input("Enter the City: ")
        cursor.execute("INSERT INTO stud_info (rno, name, phone, city) VALUES (%s, %s, %s, %s)", (rno, name, phone, city))
        db_connection.commit()
        print("Add Another Record? (y/n)")
        enter = input("Enter the option: ")
        if enter.lower() != 'y':
            var = False

# Modify Records
def Modify():
    phone = input("Enter the old Phone number to update: ")
    new_phone = input("Enter the new Phone number: ")
    cursor.execute("UPDATE stud_info SET phone = %s WHERE phone = %s", (new_phone, phone))
    db_connection.commit()
    print("Record Updated Successfully.")

# Delete Records
def Delete():
    rno = input("Enter the Roll Number to be deleted: ")
    cursor.execute("DELETE FROM stud_info WHERE rno = %s", (rno,))
    db_connection.commit()
    print("Record Deleted Successfully.")

# View Records
def View_data():
    print('List of Records:')
    cursor.execute("SELECT * FROM stud_info")
    result = cursor.fetchall()
    print("S.No --> Roll Number --> Name --> Phone Number --> City")
    sno = 1
    for record in result:
        print(f"{sno}. {record[0]} --> {record[1]} --> {record[2]} --> {record[3]}")
        sno += 1

# Exit Program
def Exit():
    cursor.close()
    db_connection.close()
    sys.exit()

# Menu function
def student_data():
    while True:
        print('\n1. Add Record')
        print('2. Modify Record')
        print('3. Delete Record')
        print('4. View Records')
        print('5. Exit')
        
        try:
            option = int(input('Enter the Option: '))
            if option == 1:
                Add()
            elif option == 2:
                Modify()
            elif option == 3:
                Delete()
            elif option == 4:
                View_data()
            elif option == 5:
                Exit()
            else:
                print("Invalid option. Please try again.")
        except ValueError:
            print("Please enter a valid number!")

# Run the program
student_data()
